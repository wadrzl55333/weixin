package com.chinacloud.common;

/**
 * 单一对象返回对象
 * Created by Speeder on 2016/1/28.
 */
public class ResponseObject<T> {
    private final int status = 200;
    private T data;

    public int getStatus() {
        return status;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public ResponseObject(T data) {
        this.data = data;
    }

    public ResponseObject() {
    }
}

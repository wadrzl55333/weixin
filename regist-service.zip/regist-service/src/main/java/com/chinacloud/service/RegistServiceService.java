/**
 * 
 */
package com.chinacloud.service;

import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;

import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.dto.ServiceOverviewDto;

@Service
public class RegistServiceService {

	private RestTemplate restTemplate = new RestTemplate();

	public ResponseObject<Map<String, Object>> RegistServiceOverviw() {
		ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
		};
		String result = "";
		ServiceOverviewDto serviceOverviewDto = new ServiceOverviewDto();
		serviceOverviewDto.setServiceId(null);
		serviceOverviewDto.setServiceName("服务名称test");
		serviceOverviewDto.setServiceCategoryId("7894326e-fdb7-4de5-9f3c-a75f8ac9aca8_1483947960000");
		serviceOverviewDto.setServiceDescription("服务介绍test");
		serviceOverviewDto.setCreatorId("bfc27112-fedf-413c-9946-4a45319c1a92");
		serviceOverviewDto.setProvider("shengting-admin@test.com");
		serviceOverviewDto.setServiceType(1);
		serviceOverviewDto.setApiType("REST");
		serviceOverviewDto.setProjectId("04cf8dff-0f48-4493-877b-4a0c224ec3f9");

		HttpHeaders headers = new HttpHeaders();
		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto, headers);
		ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate
				.exchange("http://172.16.80.90/business/service/saveServiceOverview", POST, httpEntity, responseType);
		return response.getBody();
	}
}

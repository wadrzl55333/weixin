package com.chinacloud.service;

import static org.springframework.http.HttpMethod.POST;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.dto.ServiceOverviewDto;
import com.chinacloud.resource.RegistServiceResource;

@Service
public class MonitorServiceService {

	private RestTemplate restTemplate = new RestTemplate();

	public ResponseObject<Map<String, Object>> RegistServiceOverviw() {
		ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
		};
		String result = "";
		ServiceOverviewDto serviceOverviewDto = new ServiceOverviewDto();
		serviceOverviewDto.setContext("0009f985-55a1-4a4c-a996-6c559ce0d501");
		serviceOverviewDto.setIsDefaultVersion(false);
		List<String> a=new ArrayList<String>();
	    a.add(0, "http");
	    a.add(1, "https");
	    List<String> b=new ArrayList<String>();
	    b.add(0, "Unlimited");
		serviceOverviewDto.setTransport(a);
		serviceOverviewDto.setTiers(b);
		serviceOverviewDto.setEndpointConfig(
				"{\"production_endpoints\":{\"url\":null,\"config\":null},\"sandbox_endpoints\":{\"url\":null,\"config\":null},\"endpoint_type\":\"http\"}");
		serviceOverviewDto.setName("addd");
		serviceOverviewDto.setVersion("addd");
		serviceOverviewDto.setApiDefinition(
				"{\"swagger\":\"2.0\",\"paths\":{\"/v1\":{\"get\":{\"responses\":{\"200\":{\"description\":\"\"}},\"xAuthType\":\"Application & Application User\",\"description\":\"\",\"produces\":[\"application/json\"],\"consumes\":[\"application/json\"],\"summary\":\"\",\"inputname\":\"\",\"parameterDisplay\":false,\"parameters\":[]}}}}");

		HttpHeaders headers = new HttpHeaders();
		 headers.add("X-Auth-Token","eyJhbGciOiJSUzI1NiJ9.eyJsb2dpblR5cGUiOiJhY2NvdW50IiwianRpIjoiNzNhNTVjYzQtNjYxMS00MzczLWFlNmMtZWQ1MmE5ZjQ5OGYxIiwiZXhwIjoxNDkwMTEyNTU1LCJuYmYiOjAsImlhdCI6MTQ5MDA3NjU1NSwiaXNzIjoiaHR0cDovLzE3Mi4xNi44MC44NS9hdXRoL3JlYWxtcy9tYXN0ZXIiLCJhdWQiOiJqei1taXIiLCJzdWIiOiJiZmMyNzExMi1mZWRmLTQxM2MtOTk0Ni00YTQ1MzE5YzFhOTIiLCJhenAiOiJqei1taXIiLCJzZXNzaW9uX3N0YXRlIjoiNGRlMDAxMDMtN2IxMS00ZTJmLWFmZjAtYjI2MTY3NGMyMTYxIiwiY2xpZW50X3Nlc3Npb24iOiI5ZTYwY2QzNC1iMGE1LTRmZWEtYTJhZS0wZTVlNWRkNjFlY2YiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiYWRtaW4iLCJjcmVhdGUtcmVhbG0iXX0sInJlc291cmNlX2FjY2VzcyI6eyJtYXN0ZXItcmVhbG0iOnsicm9sZXMiOlsibWFuYWdlLWV2ZW50cyIsIm1hbmFnZS1jbGllbnRzIiwidmlldy1yZWFsbSIsInZpZXctZXZlbnRzIiwibWFuYWdlLWlkZW50aXR5LXByb3ZpZGVycyIsInZpZXctaWRlbnRpdHktcHJvdmlkZXJzIiwidmlldy11c2VycyIsInZpZXctY2xpZW50cyIsImltcGVyc29uYXRpb24iLCJtYW5hZ2UtdXNlcnMiLCJtYW5hZ2UtcmVhbG0iXX0sImFjY291bnQiOnsicm9sZXMiOlsidmlldy1wcm9maWxlIiwibWFuYWdlLWFjY291bnQiXX19LCJlbWFpbCI6InNoZW5ndGluZy1hZG1pbkB0ZXN0LmNvbSIsIm5hbWUiOiIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzaGVuZ3RpbmctYWRtaW5AdGVzdC5jb20ifQ.Thmu6kXz5_fGhnXcDspTdXPysTABp_x3H2P6lUrUPiwHPEukeoaIeHTItNd5Hktj2v1LAiF_LBUaGM1kQJ1m2iOYi8XuuL5U4zpNpAKRBlKR1vWT1JNA6-3f46a48RB1sTLl-thlnvVGH-Zjxy2rDgWj_KrhjO0wEq32Uxvp4ddcMN9SZUxis8OLm4IPKH5PrrAJg7-Vme_bb1Yy8r-oBT2mp84UyOpJ7s5eFKJxf8YQgwwabU0v6zXYrjNqlneOQT1h5G0M855pLLEy1ptid5lEy7uQDwJUgTqb53IYUAsH41fuXCaJP2ZVWHqcSzdyaL45pPtgy7JAXArpFxzclw");
		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto, headers);
		String url="http://172.16.80.90/business/apiservices/{keyWord}/apis/get";
		
		url = url.replace("{keyWord}",RegistServiceResource.class.toString());

		ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate
				.exchange(url, POST, httpEntity, responseType);
		return response.getBody();
	}
}

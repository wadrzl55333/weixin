/**
 * 
 */
package com.chinacloud.resource;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.service.MonitorServiceService;
import com.chinacloud.service.RegistServiceService;

/**
 * @author zhangmenghao
 *
 */
@Controller
@RequestMapping("/test")
public class RegistServiceResource {

	@Autowired
	private RegistServiceService registServiceService;

	@RequestMapping(value = "/aaa")
	public ResponseEntity<Map<String, Object>> registSerivce() {

		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw();
		String id = result.getData().get("serviceId").toString();
		Map<String, Object> resultMap = new HashMap();
		resultMap.put("id", id);
		return ResponseEntity.ok(resultMap);
	}
	
	@Autowired
	private MonitorServiceService monitorServiceService;

	@RequestMapping(value = "/aaaa")
	public ResponseObject<Map<String, Object>> monitorSerivce() {

		ResponseObject<Map<String, Object>> result = monitorServiceService.RegistServiceOverviw();
		return result;
	}
}
